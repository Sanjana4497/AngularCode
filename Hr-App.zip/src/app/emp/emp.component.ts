import { isNull } from '@angular/compiler/src/output/output_ast';
import { Component, OnInit } from '@angular/core';
import { Project } from '../project';
import { ProjectappService } from '../projectapp.service';
@Component({
  selector: 'app-emp',
  templateUrl: './emp.component.html',
  styleUrls: ['./emp.component.css']
})
export class EmpComponent implements OnInit {

  empno:number
  name:string
  designation:string
  dateOfJoining: Date
  biodetails:string
  isViewMode:boolean
  isProjectFormVisible:boolean
  errorInProjectForm:string
  houseColor:string
  isDisable:boolean

  projects: Project[]

  constructor(private prjsvc:ProjectappService) { 
      this.empno=14841
      this.name="Sheetal Jotiram Kadam"
      this.designation="Trainee Software Engineer"
      this.dateOfJoining = new Date("03/31/2021")
      this.houseColor="lime"
      this.biodetails="An trainee engineer"
      this.projects = [
        {projectid:1001,name:"Admin",location:"Mumbai"},
        {projectid:1002,name:"Mobile App",location:"Global"}
      ]
      this.errorInProjectForm=""
      this.isViewMode=true
      this.isProjectFormVisible=false
      this.isDisable=false
      console.log('hello from constructor')
   }

   ngOnInit(): void {
    var empnoval = Number.parseInt(localStorage.getItem("empno")+"")
   
    if(!isNaN(+empnoval)){
      this.empno = +empnoval
    }
    localStorage.setItem("empno",this.empno.toString())

    this.prjsvc.getProjectsByEmpno(this.empno).subscribe(
      response=>{
        this.projects = response
      },
      error=>{console.log(error)}
    )

    sessionStorage.setItem("projects",JSON.stringify(this.projects))   
    console.log('hello from init')   
}


  toggleModeforEmpForm():void{
    this.isViewMode=!this.isViewMode
    localStorage.setItem("empno",this.empno.toString())
  }

  deleteProjectByIndex(index:number):void
  {
    this.projects.splice(index,1)
    sessionStorage.setItem("projects",JSON.stringify(this.projects))      
  }

  registerNewProject(newProject:Project):void{
    if(newProject.projectid<1000 || newProject.projectid>9999)
    {
      this.errorInProjectForm="Project Id must be of 4 digits"
    }
    else if(newProject.name.length<5 || newProject.name.length>16)
    {
      this.errorInProjectForm="Project name must be between 5 and 16"
    }

else
{
    // this.projects.push(newProject)
    // sessionStorage.setItem("projects",JSON.stringify(this.projects))      

    // this.isProjectFormVisible=false

    this.prjsvc.registerEmployeeProject(this.empno,newProject).subscribe(
      response=>{
        console.log(response)
        // fetch projects from server
        this.prjsvc.getProjectsByEmpno(this.empno).subscribe(
          response=>{
            this.projects = response
            sessionStorage.setItem("projects",
                JSON.stringify(this.projects))      
            this.errorInProjectForm=""
            this.isProjectFormVisible=false
          },
          error=>{console.log(error)}
        )
      },
      error=>{console.log(error)}
    )
  }
}

deleteProjectById(projectid:number):void{
  this.prjsvc.deleteProjectByProjectId(this.empno,projectid).subscribe(
      response=>{
          console.log(response)
          this.prjsvc.getProjectsByEmpno(this.empno).subscribe(
            response=>{
              this.projects = response    
            },
            error=>{console.log(error)}
            )
      },
      error=>{console.log(error)}
  )
}


  showProjectForm():void{
    this.isProjectFormVisible=true
  }
}









