import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-service-lines',
  templateUrl: './service-lines.component.html',
  styleUrls: ['./service-lines.component.css']
})
export class ServiceLinesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
