const express = require('express')
var cors = require('cors')


const empapp = express()
const port = 7077

//body parser config
//var bodyparser = require('body-parser')

empapp.use(express.urlencoded({extended:false}))
empapp.use(express.json())


empapp.get('/', (req, res) => {
    console.log("Employee app called");
  res.send('Employee Information Application')
})

var mysqldb = require('mysql');
const { ValueTransformer } = require('@angular/compiler/src/util')

var connection = mysqldb.createConnection({
    host:'localhost',
    user:'root',
    port: 3333,
    password:'root',
    database:'training21'
})

connection.connect()
//enable cors for all the request
empapp.use(cors())

empapp.get('/',(req,res)=>{
    console.log("Employe Service Called")
    res.send('Employee Information Application')
})

empapp.get('/emp/list/:empno',(req,res)=>{

  var empno = req.params.empno

  var selectSQL = 'select empno,projectid,name,location from employee_projects where empno=?'

  connection.query(selectSQL,[empno], function (err, rows, fields) {
      if (err) throw err

      console.log('Employees Fetched ', rows.length)
      res.send(rows)
  })
 // connection.end()

})

empapp.post('/emp/register',(req,res)=>{
  var empno = req.body.empno
  var name = req.body.name
  var projectid = req.body.projectid
  var location = req.body.location

  var insertSQL = "insert into employee_projects (empno,projectid,name,location) values(?,?,?,?)"


  connection.query(insertSQL,[empno,projectid,name,location],
    function (err, rows, fields) {
      if (err) throw err

        console.log(projectid+" Registered for "+empno)

        res.send({"empno":empno,"name":name,"projectid":projectid,"location":location})
    })
})

empapp.get("/emp/:empno/project/delete/:projectid",(req,res)=>{
  var empno = req.params.empno
  var projectid= req.params.projectid

  var deleteSQL = "delete from employee_projects where empno=? and projectid=?"

  connection.query(deleteSQL,[empno,projectid],
    function (err, rows, fields) {
      if (err) throw err

      var message =projectid+" Deleted for Employee "+empno
      console.log(message)

      res.send({"message":message})
    })

})

empapp.listen(port, () => {
  console.log(`Employee  app started and  listening at http://localhost:${port}`)
})








